from django.apps import AppConfig


class WebServerConfig(AppConfig):
    name = 'web_server'
