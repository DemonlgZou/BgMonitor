from django.apps import AppConfig


class ApiServerConfig(AppConfig):
    name = 'api_server'
