from django.apps import AppConfig


class DbServerConfig(AppConfig):
    name = 'DB_server'
